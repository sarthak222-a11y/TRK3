import { useEffect, useState } from 'react';

export interface BackgroundOption {
  label: string;
  value: string;
  previewClass: string;
  className: string;
}

export const backgrounds: BackgroundOption[] = [
  {
    label: 'Default',
    value: 'default',
    previewClass: 'bg-background',
    className: '',
  },
  {
    label: 'Warm Cream',
    value: 'warm-cream',
    previewClass: 'bg-gradient-to-br from-amber-50 to-orange-50',
    className: 'bg-warm-cream',
  },
  {
    label: 'Soft Green',
    value: 'soft-green',
    previewClass: 'bg-gradient-to-br from-emerald-50 to-teal-50',
    className: 'bg-soft-green',
  },
  {
    label: 'Calm Blue',
    value: 'calm-blue',
    previewClass: 'bg-gradient-to-br from-blue-50 to-cyan-50',
    className: 'bg-calm-blue',
  },
  {
    label: 'Gentle Wave',
    value: 'gentle-wave',
    previewClass: 'bg-gradient-to-br from-violet-50 via-purple-50 to-fuchsia-50',
    className: 'bg-gentle-wave',
  },
  {
    label: 'Animated Gradient',
    value: 'animated-gradient',
    previewClass: 'bg-gradient-to-br from-rose-50 via-amber-50 to-emerald-50',
    className: 'bg-animated-gradient',
  },
];

export function useBackground() {
  const [background, setBackgroundState] = useState<string>(() => {
    const stored = localStorage.getItem('background');
    return stored || 'default';
  });

  useEffect(() => {
    const body = document.body;
    
    // Remove all background classes
    backgrounds.forEach((bg) => {
      if (bg.className) {
        body.classList.remove(bg.className);
      }
    });

    // Add the selected background class
    const selectedBg = backgrounds.find((bg) => bg.value === background);
    if (selectedBg && selectedBg.className) {
      body.classList.add(selectedBg.className);
    }

    localStorage.setItem('background', background);
  }, [background]);

  const setBackground = (newBackground: string) => {
    setBackgroundState(newBackground);
  };

  return { background, setBackground, backgrounds };
}
