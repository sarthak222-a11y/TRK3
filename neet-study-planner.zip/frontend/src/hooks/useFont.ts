import { useEffect, useState } from 'react';

export interface FontOption {
  label: string;
  value: string;
}

export const fonts: FontOption[] = [
  { label: 'Inter (Default)', value: 'Inter' },
  { label: 'Roboto', value: 'Roboto' },
  { label: 'Open Sans', value: 'Open Sans' },
  { label: 'Poppins', value: 'Poppins' },
  { label: 'Lato', value: 'Lato' },
];

export function useFont() {
  const [font, setFontState] = useState<string>(() => {
    const stored = localStorage.getItem('font');
    return stored || 'Inter';
  });

  useEffect(() => {
    document.documentElement.style.setProperty('--font-family', font);
    localStorage.setItem('font', font);
  }, [font]);

  const setFont = (newFont: string) => {
    setFontState(newFont);
  };

  return { font, setFont, fonts };
}
