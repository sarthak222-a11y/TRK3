import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export interface Task {
    id: bigint;
    title: string;
    subject: Subject;
    date: bigint;
    completed: boolean;
    durationEstimate: bigint;
    chapterName: string;
}
export enum Subject {
    biology = "biology",
    chemistry = "chemistry",
    physics = "physics"
}
export interface backendInterface {
    addChapter(name: string, subject: Subject): Promise<void>;
    addTask(title: string, subject: Subject, chapterName: string, durationEstimate: bigint, date: bigint): Promise<bigint>;
    completeTask(taskId: bigint): Promise<void>;
    getTasks(): Promise<Array<Task>>;
}
