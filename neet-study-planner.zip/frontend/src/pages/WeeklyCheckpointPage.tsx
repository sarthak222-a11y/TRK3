import { useState } from 'react';
import { ChevronLeft, ChevronRight, Plus, Target } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface Goal {
  id: string;
  type: 'chapter' | 'test' | 'revision';
  subject: string;
  chapter?: string;
  description: string;
  progress: number;
}

export default function WeeklyCheckpointPage() {
  const [currentWeek, setCurrentWeek] = useState(0);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [goalType, setGoalType] = useState<'chapter' | 'test' | 'revision'>('chapter');
  const [subject, setSubject] = useState('');
  const [chapter, setChapter] = useState('');
  const [description, setDescription] = useState('');

  // Mock goals - in production, fetch from backend
  const [goals, setGoals] = useState<Goal[]>([
    {
      id: '1',
      type: 'chapter',
      subject: 'Physics',
      chapter: 'Mechanics',
      description: 'Complete Mechanics theory and solve 20 PYQs',
      progress: 75,
    },
    {
      id: '2',
      type: 'test',
      subject: 'Chemistry',
      description: 'Complete Mock Test 5',
      progress: 100,
    },
    {
      id: '3',
      type: 'revision',
      subject: 'Biology',
      chapter: 'Cell Biology',
      description: 'Revise Cell Biology chapter',
      progress: 40,
    },
    {
      id: '4',
      type: 'chapter',
      subject: 'Chemistry',
      chapter: 'Organic Chemistry',
      description: 'Complete Organic Chemistry reactions',
      progress: 20,
    },
  ]);

  const getWeekDates = (weekOffset: number) => {
    const today = new Date();
    const currentDay = today.getDay();
    const diff = today.getDate() - currentDay + (currentDay === 0 ? -6 : 1) + weekOffset * 7;
    const monday = new Date(today.setDate(diff));
    const sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 6);
    return { monday, sunday };
  };

  const { monday, sunday } = getWeekDates(currentWeek);

  const handleAddGoal = () => {
    if (!description || !subject) {
      alert('Please fill all required fields');
      return;
    }

    const newGoal: Goal = {
      id: Date.now().toString(),
      type: goalType,
      subject,
      chapter: goalType === 'chapter' || goalType === 'revision' ? chapter : undefined,
      description,
      progress: 0,
    };

    setGoals([...goals, newGoal]);
    setIsDialogOpen(false);
    setDescription('');
    setSubject('');
    setChapter('');
  };

  const getGoalTypeColor = (type: string) => {
    switch (type) {
      case 'chapter':
        return 'bg-chart-1/10 text-chart-1 border-chart-1/20';
      case 'test':
        return 'bg-chart-2/10 text-chart-2 border-chart-2/20';
      case 'revision':
        return 'bg-chart-3/10 text-chart-3 border-chart-3/20';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Weekly Checkpoints</h1>
          <p className="text-muted-foreground mt-1">Set and track your weekly study goals</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Add Goal
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Weekly Goal</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Goal Type</Label>
                <Select value={goalType} onValueChange={(value: any) => setGoalType(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="chapter">Chapter Completion</SelectItem>
                    <SelectItem value="test">Mock Test</SelectItem>
                    <SelectItem value="revision">Revision</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Subject</Label>
                <Select value={subject} onValueChange={setSubject}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select subject" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Physics">Physics</SelectItem>
                    <SelectItem value="Chemistry">Chemistry</SelectItem>
                    <SelectItem value="Biology">Biology</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {(goalType === 'chapter' || goalType === 'revision') && (
                <div className="space-y-2">
                  <Label>Chapter (Optional)</Label>
                  <Input
                    placeholder="e.g., Mechanics"
                    value={chapter}
                    onChange={(e) => setChapter(e.target.value)}
                  />
                </div>
              )}
              <div className="space-y-2">
                <Label>Description</Label>
                <Input
                  placeholder="Describe your goal"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </div>
              <Button onClick={handleAddGoal} className="w-full">
                Add Goal
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <Button variant="outline" size="icon" onClick={() => setCurrentWeek(currentWeek - 1)}>
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <CardTitle>
              Week of {monday.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} -{' '}
              {sunday.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
            </CardTitle>
            <Button variant="outline" size="icon" onClick={() => setCurrentWeek(currentWeek + 1)}>
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {goals.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No goals set for this week. Click "Add Goal" to create one.
            </div>
          ) : (
            <div className="space-y-4">
              {goals.map((goal) => (
                <div
                  key={goal.id}
                  className={`p-4 rounded-lg border-2 ${
                    goal.progress < 100 && currentWeek === 0
                      ? 'border-destructive/30 bg-destructive/5'
                      : 'border-border'
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="outline" className={getGoalTypeColor(goal.type)}>
                          {goal.type.charAt(0).toUpperCase() + goal.type.slice(1)}
                        </Badge>
                        <Badge variant="outline">{goal.subject}</Badge>
                        {goal.chapter && <span className="text-sm text-muted-foreground">{goal.chapter}</span>}
                      </div>
                      <p className="text-foreground font-medium">{goal.description}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-foreground">{goal.progress}%</div>
                      {goal.progress < 100 && currentWeek === 0 && (
                        <span className="text-xs text-destructive">Incomplete</span>
                      )}
                    </div>
                  </div>
                  <Progress value={goal.progress} className="h-2" />
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
