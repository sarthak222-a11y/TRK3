import { useState } from 'react';
import { Plus, TrendingUp, TrendingDown } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface MockTest {
  id: string;
  name: string;
  date: string;
  totalMarks: number;
  physicsMarks: number;
  chemistryMarks: number;
  biologyMarks: number;
}

export default function AnalyticsPage() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [testName, setTestName] = useState('');
  const [testDate, setTestDate] = useState('');
  const [totalMarks, setTotalMarks] = useState('');
  const [physicsMarks, setPhysicsMarks] = useState('');
  const [chemistryMarks, setChemistryMarks] = useState('');
  const [biologyMarks, setBiologyMarks] = useState('');

  // Mock data - in production, fetch from backend
  const [tests, setTests] = useState<MockTest[]>([
    {
      id: '1',
      name: 'Mock Test 1',
      date: '2026-01-15',
      totalMarks: 620,
      physicsMarks: 160,
      chemistryMarks: 220,
      biologyMarks: 240,
    },
    {
      id: '2',
      name: 'Mock Test 2',
      date: '2026-01-29',
      totalMarks: 650,
      physicsMarks: 170,
      chemistryMarks: 230,
      biologyMarks: 250,
    },
    {
      id: '3',
      name: 'Mock Test 3',
      date: '2026-02-12',
      totalMarks: 680,
      physicsMarks: 180,
      chemistryMarks: 240,
      biologyMarks: 260,
    },
  ]);

  const handleAddTest = () => {
    if (!testName || !testDate || !totalMarks || !physicsMarks || !chemistryMarks || !biologyMarks) {
      alert('Please fill all fields');
      return;
    }

    const newTest: MockTest = {
      id: Date.now().toString(),
      name: testName,
      date: testDate,
      totalMarks: parseInt(totalMarks),
      physicsMarks: parseInt(physicsMarks),
      chemistryMarks: parseInt(chemistryMarks),
      biologyMarks: parseInt(biologyMarks),
    };

    setTests([...tests, newTest].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()));
    setIsDialogOpen(false);
    setTestName('');
    setTestDate('');
    setTotalMarks('');
    setPhysicsMarks('');
    setChemistryMarks('');
    setBiologyMarks('');
  };

  const calculateStats = () => {
    if (tests.length === 0) return null;

    const avgTotal = Math.round(tests.reduce((sum, t) => sum + t.totalMarks, 0) / tests.length);
    const avgPhysics = Math.round(tests.reduce((sum, t) => sum + t.physicsMarks, 0) / tests.length);
    const avgChemistry = Math.round(tests.reduce((sum, t) => sum + t.chemistryMarks, 0) / tests.length);
    const avgBiology = Math.round(tests.reduce((sum, t) => sum + t.biologyMarks, 0) / tests.length);

    const bestTotal = Math.max(...tests.map((t) => t.totalMarks));
    const bestPhysics = Math.max(...tests.map((t) => t.physicsMarks));
    const bestChemistry = Math.max(...tests.map((t) => t.chemistryMarks));
    const bestBiology = Math.max(...tests.map((t) => t.biologyMarks));

    const weakest =
      avgPhysics < avgChemistry && avgPhysics < avgBiology
        ? 'Physics'
        : avgChemistry < avgBiology
          ? 'Chemistry'
          : 'Biology';

    return {
      avgTotal,
      avgPhysics,
      avgChemistry,
      avgBiology,
      bestTotal,
      bestPhysics,
      bestChemistry,
      bestBiology,
      weakest,
    };
  };

  const stats = calculateStats();

  const totalMarksData = tests.map((test) => ({
    name: test.name,
    marks: test.totalMarks,
  }));

  const subjectMarksData = tests.map((test) => ({
    name: test.name,
    Physics: test.physicsMarks,
    Chemistry: test.chemistryMarks,
    Biology: test.biologyMarks,
  }));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Performance Analytics</h1>
          <p className="text-muted-foreground mt-1">Track and analyze your mock test performance</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Add Test
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Mock Test Result</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Test Name</Label>
                <Input placeholder="e.g., Mock Test 4" value={testName} onChange={(e) => setTestName(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Date</Label>
                <Input type="date" value={testDate} onChange={(e) => setTestDate(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Total Marks (out of 720)</Label>
                <Input
                  type="number"
                  placeholder="e.g., 650"
                  value={totalMarks}
                  onChange={(e) => setTotalMarks(e.target.value)}
                  max="720"
                />
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Physics</Label>
                  <Input
                    type="number"
                    placeholder="180"
                    value={physicsMarks}
                    onChange={(e) => setPhysicsMarks(e.target.value)}
                    max="180"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Chemistry</Label>
                  <Input
                    type="number"
                    placeholder="180"
                    value={chemistryMarks}
                    onChange={(e) => setChemistryMarks(e.target.value)}
                    max="180"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Biology</Label>
                  <Input
                    type="number"
                    placeholder="360"
                    value={biologyMarks}
                    onChange={(e) => setBiologyMarks(e.target.value)}
                    max="360"
                  />
                </div>
              </div>
              <Button onClick={handleAddTest} className="w-full">
                Add Test Result
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Average Score</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{stats.avgTotal}</div>
              <p className="text-xs text-muted-foreground mt-1">out of 720</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Best Score</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-success">{stats.bestTotal}</div>
              <p className="text-xs text-muted-foreground mt-1">Personal best</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Tests Taken</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{tests.length}</div>
              <p className="text-xs text-muted-foreground mt-1">Total attempts</p>
            </CardContent>
          </Card>

          <Card className="border-2 border-destructive/20">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <TrendingDown className="w-4 h-4 text-destructive" />
                Weakest Subject
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-destructive">{stats.weakest}</div>
              <p className="text-xs text-muted-foreground mt-1">Needs more focus</p>
            </CardContent>
          </Card>
        </div>
      )}

      {tests.length === 0 ? (
        <Card>
          <CardContent className="py-12">
            <div className="text-center text-muted-foreground">
              No test data available. Click "Add Test" to record your first mock test result.
            </div>
          </CardContent>
        </Card>
      ) : (
        <>
          <Card>
            <CardHeader>
              <CardTitle>Total Marks Trend</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={totalMarksData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis domain={[0, 720]} />
                  <Tooltip />
                  <Bar dataKey="marks" fill="oklch(var(--success))" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Subject-wise Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={subjectMarksData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="Physics" fill="oklch(var(--chart-1))" />
                  <Bar dataKey="Chemistry" fill="oklch(var(--chart-2))" />
                  <Bar dataKey="Biology" fill="oklch(var(--chart-3))" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {stats && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Physics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Average</span>
                    <span className="font-semibold">{stats.avgPhysics}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Best</span>
                    <span className="font-semibold text-success">{stats.bestPhysics}</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Chemistry</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Average</span>
                    <span className="font-semibold">{stats.avgChemistry}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Best</span>
                    <span className="font-semibold text-success">{stats.bestChemistry}</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Biology</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Average</span>
                    <span className="font-semibold">{stats.avgBiology}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Best</span>
                    <span className="font-semibold text-success">{stats.bestBiology}</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </>
      )}
    </div>
  );
}
