import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface ChapterProgress {
  name: string;
  theoryComplete: boolean;
  pyqsSolved: number;
  revisionComplete: boolean;
  mastered: boolean;
}

export default function SyllabusTrackerPage() {
  // Mock data - in production, fetch from backend
  const [syllabusData, setSyllabusData] = useState<Record<string, ChapterProgress[]>>({
    Physics: [
      { name: 'Mechanics', theoryComplete: true, pyqsSolved: 25, revisionComplete: true, mastered: false },
      { name: 'Thermodynamics', theoryComplete: true, pyqsSolved: 15, revisionComplete: false, mastered: false },
      { name: 'Optics', theoryComplete: false, pyqsSolved: 0, revisionComplete: false, mastered: false },
      { name: 'Electromagnetism', theoryComplete: true, pyqsSolved: 20, revisionComplete: true, mastered: true },
      { name: 'Modern Physics', theoryComplete: false, pyqsSolved: 5, revisionComplete: false, mastered: false },
    ],
    Chemistry: [
      { name: 'Physical Chemistry', theoryComplete: true, pyqsSolved: 30, revisionComplete: true, mastered: true },
      { name: 'Organic Chemistry', theoryComplete: true, pyqsSolved: 18, revisionComplete: false, mastered: false },
      { name: 'Inorganic Chemistry', theoryComplete: false, pyqsSolved: 8, revisionComplete: false, mastered: false },
      {
        name: 'Environmental Chemistry',
        theoryComplete: true,
        pyqsSolved: 12,
        revisionComplete: true,
        mastered: false,
      },
    ],
    Biology: [
      { name: 'Cell Biology', theoryComplete: true, pyqsSolved: 22, revisionComplete: true, mastered: true },
      { name: 'Genetics', theoryComplete: true, pyqsSolved: 28, revisionComplete: true, mastered: false },
      { name: 'Ecology', theoryComplete: false, pyqsSolved: 10, revisionComplete: false, mastered: false },
      { name: 'Human Physiology', theoryComplete: true, pyqsSolved: 35, revisionComplete: true, mastered: true },
      { name: 'Plant Physiology', theoryComplete: false, pyqsSolved: 5, revisionComplete: false, mastered: false },
    ],
  });

  const calculateChapterCompletion = (chapter: ChapterProgress): number => {
    let completed = 0;
    if (chapter.theoryComplete) completed += 25;
    if (chapter.pyqsSolved >= 20) completed += 25;
    else completed += (chapter.pyqsSolved / 20) * 25;
    if (chapter.revisionComplete) completed += 25;
    if (chapter.mastered) completed += 25;
    return Math.round(completed);
  };

  const calculateSubjectCompletion = (chapters: ChapterProgress[]): number => {
    const total = chapters.reduce((sum, ch) => sum + calculateChapterCompletion(ch), 0);
    return Math.round(total / chapters.length);
  };

  const calculateOverallCompletion = (): number => {
    const subjects = Object.values(syllabusData);
    const total = subjects.reduce((sum, chapters) => sum + calculateSubjectCompletion(chapters), 0);
    return Math.round(total / subjects.length);
  };

  const getCompletionColor = (percentage: number): string => {
    if (percentage === 0) return 'bg-destructive/10 border-destructive/30';
    if (percentage < 100) return 'bg-warning/10 border-warning/30';
    return 'bg-success/10 border-success/30';
  };

  const updateChapter = (subject: string, chapterIndex: number, updates: Partial<ChapterProgress>) => {
    setSyllabusData((prev) => ({
      ...prev,
      [subject]: prev[subject].map((ch, idx) => (idx === chapterIndex ? { ...ch, ...updates } : ch)),
    }));
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Syllabus Tracker</h1>
        <p className="text-muted-foreground mt-1">Monitor your progress across all chapters</p>
      </div>

      <Card className="border-2 border-success/20">
        <CardHeader>
          <CardTitle>Overall Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="font-medium">Total Completion</span>
              <span className="text-muted-foreground">{calculateOverallCompletion()}%</span>
            </div>
            <Progress value={calculateOverallCompletion()} className="h-3" />
          </div>
        </CardContent>
      </Card>

      <Accordion type="multiple" className="space-y-4">
        {Object.entries(syllabusData).map(([subject, chapters]) => {
          const subjectCompletion = calculateSubjectCompletion(chapters);
          return (
            <AccordionItem key={subject} value={subject} className="border-2 rounded-lg px-4">
              <AccordionTrigger className="hover:no-underline">
                <div className="flex items-center justify-between w-full pr-4">
                  <span className="text-lg font-semibold">{subject}</span>
                  <div className="flex items-center gap-4">
                    <span className="text-sm text-muted-foreground">{subjectCompletion}% Complete</span>
                    <Progress value={subjectCompletion} className="w-32 h-2" />
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-3 pt-4">
                  {chapters.map((chapter, index) => {
                    const completion = calculateChapterCompletion(chapter);
                    return (
                      <div
                        key={chapter.name}
                        className={`p-4 rounded-lg border-2 ${getCompletionColor(completion)}`}
                      >
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="font-medium text-foreground">{chapter.name}</h4>
                          <span className="text-sm font-semibold">{completion}%</span>
                        </div>
                        <Progress value={completion} className="h-2 mb-4" />
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div className="flex items-center gap-2">
                            <Checkbox
                              id={`${subject}-${index}-theory`}
                              checked={chapter.theoryComplete}
                              onCheckedChange={(checked) =>
                                updateChapter(subject, index, { theoryComplete: checked as boolean })
                              }
                            />
                            <Label htmlFor={`${subject}-${index}-theory`} className="text-sm cursor-pointer">
                              Theory Complete
                            </Label>
                          </div>
                          <div className="flex items-center gap-2">
                            <Label htmlFor={`${subject}-${index}-pyqs`} className="text-sm">
                              PYQs:
                            </Label>
                            <Input
                              id={`${subject}-${index}-pyqs`}
                              type="number"
                              value={chapter.pyqsSolved}
                              onChange={(e) =>
                                updateChapter(subject, index, { pyqsSolved: parseInt(e.target.value) || 0 })
                              }
                              className="w-20 h-8"
                              min="0"
                            />
                          </div>
                          <div className="flex items-center gap-2">
                            <Checkbox
                              id={`${subject}-${index}-revision`}
                              checked={chapter.revisionComplete}
                              onCheckedChange={(checked) =>
                                updateChapter(subject, index, { revisionComplete: checked as boolean })
                              }
                            />
                            <Label htmlFor={`${subject}-${index}-revision`} className="text-sm cursor-pointer">
                              Revision Done
                            </Label>
                          </div>
                          <div className="flex items-center gap-2">
                            <Checkbox
                              id={`${subject}-${index}-mastered`}
                              checked={chapter.mastered}
                              onCheckedChange={(checked) =>
                                updateChapter(subject, index, { mastered: checked as boolean })
                              }
                            />
                            <Label htmlFor={`${subject}-${index}-mastered`} className="text-sm cursor-pointer">
                              Mastered
                            </Label>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </AccordionContent>
            </AccordionItem>
          );
        })}
      </Accordion>
    </div>
  );
}
