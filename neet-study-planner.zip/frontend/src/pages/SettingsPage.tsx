import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Settings, Moon, Sun, Type, Palette } from 'lucide-react';
import { useTheme } from '../hooks/useTheme';
import { useFont } from '../hooks/useFont';
import { useBackground } from '../hooks/useBackground';

export default function SettingsPage() {
  const { theme, toggleTheme } = useTheme();
  const { font, setFont, fonts } = useFont();
  const { background, setBackground, backgrounds } = useBackground();

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-12 h-12 rounded-lg bg-success/10 flex items-center justify-center">
          <Settings className="w-6 h-6 text-success" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-foreground">Settings</h1>
          <p className="text-muted-foreground">Customize your study environment</p>
        </div>
      </div>

      {/* Theme Settings */}
      <Card className="border-border shadow-sm">
        <CardHeader>
          <div className="flex items-center gap-2">
            {theme === 'dark' ? (
              <Moon className="w-5 h-5 text-success" />
            ) : (
              <Sun className="w-5 h-5 text-warning" />
            )}
            <CardTitle>Theme Mode</CardTitle>
          </div>
          <CardDescription>
            Switch between light and dark mode for comfortable studying
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="theme-toggle" className="text-base font-medium">
                Dark Mode
              </Label>
              <p className="text-sm text-muted-foreground">
                {theme === 'dark' ? 'Currently using dark theme' : 'Currently using light theme'}
              </p>
            </div>
            <Switch
              id="theme-toggle"
              checked={theme === 'dark'}
              onCheckedChange={toggleTheme}
            />
          </div>
        </CardContent>
      </Card>

      {/* Font Settings */}
      <Card className="border-border shadow-sm">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Type className="w-5 h-5 text-success" />
            <CardTitle>Font Family</CardTitle>
          </div>
          <CardDescription>
            Choose a font that helps you focus and read comfortably
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="font-select" className="text-base font-medium">
                Select Font
              </Label>
              <Select value={font} onValueChange={setFont}>
                <SelectTrigger id="font-select" className="w-full">
                  <SelectValue placeholder="Choose a font" />
                </SelectTrigger>
                <SelectContent>
                  {fonts.map((fontOption) => (
                    <SelectItem
                      key={fontOption.value}
                      value={fontOption.value}
                      style={{ fontFamily: fontOption.value }}
                    >
                      {fontOption.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="p-4 rounded-lg bg-muted/50 border border-border">
              <p className="text-sm text-muted-foreground mb-2">Preview:</p>
              <p className="text-lg">
                The quick brown fox jumps over the lazy dog. 0123456789
              </p>
              <p className="text-sm mt-2 text-muted-foreground">
                Focus on your NEET preparation with clarity and confidence.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Background Settings */}
      <Card className="border-border shadow-sm">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Palette className="w-5 h-5 text-success" />
            <CardTitle>Background Style</CardTitle>
          </div>
          <CardDescription>
            Select a subtle background that enhances your study experience
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Label className="text-base font-medium">Choose Background</Label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {backgrounds.map((bg) => (
                <button
                  key={bg.value}
                  onClick={() => setBackground(bg.value)}
                  className={`relative p-4 rounded-lg border-2 transition-all hover:scale-105 ${
                    background === bg.value
                      ? 'border-success shadow-md'
                      : 'border-border hover:border-success/50'
                  }`}
                >
                  <div
                    className={`w-full h-24 rounded-md mb-2 ${bg.previewClass}`}
                  />
                  <p className="text-sm font-medium text-center">{bg.label}</p>
                  {background === bg.value && (
                    <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-success flex items-center justify-center">
                      <svg
                        className="w-3 h-3 text-success-foreground"
                        fill="none"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="text-center text-sm text-muted-foreground pt-4">
        <p>All settings are saved automatically and persist across sessions</p>
      </div>
    </div>
  );
}
