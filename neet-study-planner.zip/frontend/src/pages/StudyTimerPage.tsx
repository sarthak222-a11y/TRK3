import { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Subject } from '@/backend';

export default function StudyTimerPage() {
  const [isRunning, setIsRunning] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [selectedSubject, setSelectedSubject] = useState<Subject | ''>('');
  const [selectedChapter, setSelectedChapter] = useState('');

  // Mock chapters - in production, fetch from backend
  const chapters = {
    physics: ['Mechanics', 'Thermodynamics', 'Optics', 'Electromagnetism', 'Modern Physics'],
    chemistry: ['Physical Chemistry', 'Organic Chemistry', 'Inorganic Chemistry', 'Environmental Chemistry'],
    biology: ['Cell Biology', 'Genetics', 'Ecology', 'Human Physiology', 'Plant Physiology'],
  };

  // Mock study data - in production, fetch from backend
  const todayTotal = 245; // minutes
  const weekTotal = 1680; // minutes
  const subjectBreakdown = [
    { subject: 'Physics', percentage: 35, minutes: 588 },
    { subject: 'Chemistry', percentage: 40, minutes: 672 },
    { subject: 'Biology', percentage: 25, minutes: 420 },
  ];

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRunning) {
      interval = setInterval(() => {
        setSeconds((s) => s + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning]);

  const formatTime = (totalSeconds: number) => {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleStart = () => {
    if (!selectedSubject || !selectedChapter) {
      alert('Please select subject and chapter before starting timer');
      return;
    }
    setIsRunning(true);
  };

  const handleStop = () => {
    setIsRunning(false);
    // In production: save time entry to backend
    if (seconds > 0) {
      alert(`Session saved: ${Math.floor(seconds / 60)} minutes for ${selectedChapter}`);
    }
  };

  const handleReset = () => {
    setIsRunning(false);
    setSeconds(0);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Study Timer</h1>
        <p className="text-muted-foreground mt-1">Track your study sessions by subject and chapter</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-2">
          <CardHeader>
            <CardTitle>Active Timer</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center">
              <div className="text-6xl font-bold text-success font-mono">{formatTime(seconds)}</div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Subject</Label>
                <Select
                  value={selectedSubject}
                  onValueChange={(value) => {
                    setSelectedSubject(value as Subject);
                    setSelectedChapter('');
                  }}
                  disabled={isRunning}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select subject" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="physics">Physics</SelectItem>
                    <SelectItem value="chemistry">Chemistry</SelectItem>
                    <SelectItem value="biology">Biology</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Chapter</Label>
                <Select
                  value={selectedChapter}
                  onValueChange={setSelectedChapter}
                  disabled={!selectedSubject || isRunning}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select chapter" />
                  </SelectTrigger>
                  <SelectContent>
                    {selectedSubject &&
                      chapters[selectedSubject as keyof typeof chapters].map((chapter) => (
                        <SelectItem key={chapter} value={chapter}>
                          {chapter}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex gap-2">
              {!isRunning ? (
                <Button onClick={handleStart} className="flex-1" size="lg">
                  <Play className="w-5 h-5 mr-2" />
                  Start
                </Button>
              ) : (
                <Button onClick={handleStop} variant="destructive" className="flex-1" size="lg">
                  <Pause className="w-5 h-5 mr-2" />
                  Stop
                </Button>
              )}
              <Button onClick={handleReset} variant="outline" size="lg">
                <RotateCcw className="w-5 h-5" />
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Study Time Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Today's Total</span>
                <span className="text-2xl font-bold text-foreground">
                  {Math.floor(todayTotal / 60)}h {todayTotal % 60}m
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">This Week's Total</span>
                <span className="text-2xl font-bold text-foreground">
                  {Math.floor(weekTotal / 60)}h {weekTotal % 60}m
                </span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Subject-wise Breakdown</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {subjectBreakdown.map((item) => (
                <div key={item.subject} className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">{item.subject}</span>
                    <span className="text-muted-foreground">
                      {item.percentage}% ({Math.floor(item.minutes / 60)}h {item.minutes % 60}m)
                    </span>
                  </div>
                  <Progress value={item.percentage} className="h-2" />
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
