import { Flame, Calendar, TrendingUp, Lightbulb } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function InsightsPage() {
  // Mock data - in production, fetch from backend
  const studyStreak = 12;
  const weeklyConsistency = 86; // percentage
  const daysStudiedThisWeek = 6;

  const timeVsMarksData = [
    { week: 'Week 1', studyHours: 25, avgMarks: 580 },
    { week: 'Week 2', studyHours: 28, avgMarks: 600 },
    { week: 'Week 3', studyHours: 30, avgMarks: 620 },
    { week: 'Week 4', studyHours: 32, avgMarks: 650 },
    { week: 'Week 5', studyHours: 35, avgMarks: 680 },
  ];

  const suggestions = [
    {
      icon: TrendingUp,
      title: 'Increase Physics Study Time',
      description: 'Your Physics scores are below average. Consider dedicating 20% more time to this subject.',
      priority: 'high',
    },
    {
      icon: Calendar,
      title: 'Maintain Your Consistency',
      description: 'Great job! You studied 6 out of 7 days this week. Keep up the momentum.',
      priority: 'medium',
    },
    {
      icon: Flame,
      title: 'Study Streak Active',
      description: "You're on a 12-day streak! Don't break it now - even 30 minutes counts.",
      priority: 'medium',
    },
    {
      icon: Lightbulb,
      title: 'Focus on Weak Chapters',
      description: 'Thermodynamics and Optics need more attention. Schedule revision sessions this week.',
      priority: 'high',
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Stats & Insights</h1>
        <p className="text-muted-foreground mt-1">Track your progress and get personalized recommendations</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="border-2 border-success/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-success" />
              Study Streak
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-4">
              <div className="text-6xl font-bold text-success">{studyStreak}</div>
              <p className="text-lg text-muted-foreground mt-2">Consecutive Days</p>
              <p className="text-sm text-muted-foreground mt-4">
                Keep going! Consistency is key to success. 🔥
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-chart-2/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-chart-2" />
              Weekly Consistency
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="text-center">
                <div className="text-6xl font-bold text-chart-2">{weeklyConsistency}%</div>
                <p className="text-lg text-muted-foreground mt-2">
                  {daysStudiedThisWeek} out of 7 days
                </p>
              </div>
              <Progress value={weeklyConsistency} className="h-3" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Study Time vs Performance Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={timeVsMarksData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="week" />
              <YAxis yAxisId="left" orientation="left" stroke="oklch(var(--chart-1))" />
              <YAxis yAxisId="right" orientation="right" stroke="oklch(var(--chart-2))" />
              <Tooltip />
              <Legend />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="studyHours"
                stroke="oklch(var(--chart-1))"
                strokeWidth={2}
                name="Study Hours"
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="avgMarks"
                stroke="oklch(var(--chart-2))"
                strokeWidth={2}
                name="Average Marks"
              />
            </LineChart>
          </ResponsiveContainer>
          <p className="text-sm text-muted-foreground text-center mt-4">
            Your performance improves with consistent study time. Keep increasing your weekly hours!
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-warning" />
            Actionable Suggestions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {suggestions.map((suggestion, index) => {
              const Icon = suggestion.icon;
              return (
                <div
                  key={index}
                  className={`p-4 rounded-lg border-2 ${
                    suggestion.priority === 'high'
                      ? 'border-destructive/20 bg-destructive/5'
                      : 'border-border bg-card'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={`p-2 rounded-lg ${
                        suggestion.priority === 'high' ? 'bg-destructive/10' : 'bg-success/10'
                      }`}
                    >
                      <Icon
                        className={`w-5 h-5 ${
                          suggestion.priority === 'high' ? 'text-destructive' : 'text-success'
                        }`}
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground mb-1">{suggestion.title}</h3>
                      <p className="text-sm text-muted-foreground">{suggestion.description}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
