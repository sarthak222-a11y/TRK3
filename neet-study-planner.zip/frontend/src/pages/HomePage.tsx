import { useNavigate } from '@tanstack/react-router';
import { Timer, CheckSquare, Target, BarChart3, TrendingUp, BookOpen } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import CountdownWidget from '@/components/CountdownWidget';
import TodayTasksSummary from '@/components/TodayTasksSummary';

export default function HomePage() {
  const navigate = useNavigate();

  const sections = [
    {
      title: 'Study Timer',
      description: 'Track your study time by subject and chapter',
      icon: Timer,
      path: '/timer',
      color: 'text-chart-1',
    },
    {
      title: 'Task Manager',
      description: 'Plan and complete your daily study tasks',
      icon: CheckSquare,
      path: '/tasks',
      color: 'text-chart-2',
    },
    {
      title: 'Syllabus Tracker',
      description: 'Monitor your progress across all chapters',
      icon: Target,
      path: '/syllabus',
      color: 'text-chart-3',
    },
    {
      title: 'Weekly Checkpoints',
      description: 'Set and track weekly study goals',
      icon: Target,
      path: '/checkpoints',
      color: 'text-chart-4',
    },
    {
      title: 'Performance Analytics',
      description: 'Analyze your mock test performance',
      icon: BarChart3,
      path: '/analytics',
      color: 'text-chart-5',
    },
    {
      title: 'Stats & Insights',
      description: 'View study streaks and get recommendations',
      icon: TrendingUp,
      path: '/insights',
      color: 'text-success',
    },
  ];

  return (
    <div className="space-y-8">
      <div className="text-center space-y-2">
        <h1 className="text-4xl font-bold text-foreground">Welcome to Your NEET Journey</h1>
        <p className="text-lg text-muted-foreground">Stay focused, stay consistent, achieve excellence</p>
      </div>

      <CountdownWidget />

      <TodayTasksSummary />

      <div>
        <h2 className="text-2xl font-semibold text-foreground mb-4">Quick Access</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {sections.map((section) => {
            const Icon = section.icon;
            return (
              <Card
                key={section.path}
                className="cursor-pointer hover:shadow-lg transition-shadow border-2 hover:border-success/50"
                onClick={() => navigate({ to: section.path })}
              >
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg bg-muted ${section.color}`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <CardTitle className="text-lg">{section.title}</CardTitle>
                  </div>
                  <CardDescription>{section.description}</CardDescription>
                </CardHeader>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}
