import { RouterProvider, createRouter, createRoute, createRootRoute } from '@tanstack/react-router';
import Layout from './components/Layout';
import HomePage from './pages/HomePage';
import StudyTimerPage from './pages/StudyTimerPage';
import TaskManagerPage from './pages/TaskManagerPage';
import SyllabusTrackerPage from './pages/SyllabusTrackerPage';
import AnalyticsPage from './pages/AnalyticsPage';
import InsightsPage from './pages/InsightsPage';
import WeeklyCheckpointPage from './pages/WeeklyCheckpointPage';
import SettingsPage from './pages/SettingsPage';

const rootRoute = createRootRoute({
  component: Layout,
});

const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/',
  component: HomePage,
});

const studyTimerRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/timer',
  component: StudyTimerPage,
});

const taskManagerRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/tasks',
  component: TaskManagerPage,
});

const syllabusRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/syllabus',
  component: SyllabusTrackerPage,
});

const analyticsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/analytics',
  component: AnalyticsPage,
});

const insightsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/insights',
  component: InsightsPage,
});

const checkpointsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/checkpoints',
  component: WeeklyCheckpointPage,
});

const settingsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/settings',
  component: SettingsPage,
});

const routeTree = rootRoute.addChildren([
  indexRoute,
  studyTimerRoute,
  taskManagerRoute,
  syllabusRoute,
  analyticsRoute,
  insightsRoute,
  checkpointsRoute,
  settingsRoute,
]);

const router = createRouter({ routeTree });

declare module '@tanstack/react-router' {
  interface Register {
    router: typeof router;
  }
}

export default function App() {
  return <RouterProvider router={router} />;
}
