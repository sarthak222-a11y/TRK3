import { CheckCircle2, Circle, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useGetTasks } from '@/hooks/useQueries';

export default function TodayTasksSummary() {
  const { data: tasks = [], isLoading } = useGetTasks();

  // Filter tasks for today
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayTimestamp = BigInt(today.getTime() * 1000000); // Convert to nanoseconds

  const todayTasks = tasks.filter((task) => {
    const taskDate = new Date(Number(task.date) / 1000000);
    taskDate.setHours(0, 0, 0, 0);
    return taskDate.getTime() === today.getTime();
  });

  const completedCount = todayTasks.filter((t) => t.completed).length;
  const pendingCount = todayTasks.filter((t) => !t.completed).length;
  const totalMinutes = todayTasks.reduce((sum, t) => sum + Number(t.durationEstimate), 0);

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-8">
          <div className="text-center text-muted-foreground">Loading tasks...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold text-foreground mb-4">Today's Overview</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-2 border-success/20">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-success" />
              Completed Tasks
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-success">{completedCount}</div>
          </CardContent>
        </Card>

        <Card className="border-2 border-warning/20">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Circle className="w-4 h-4 text-warning" />
              Pending Tasks
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-warning">{pendingCount}</div>
          </CardContent>
        </Card>

        <Card className="border-2 border-chart-2/20">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Clock className="w-4 h-4 text-chart-2" />
              Planned Study Time
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-chart-2">
              {Math.floor(totalMinutes / 60)}h {totalMinutes % 60}m
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
