import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAddTask } from '@/hooks/useQueries';
import { Subject } from '@/backend';

interface TaskCreationFormProps {
  selectedDate: Date;
  onSuccess: () => void;
  onCancel: () => void;
}

export default function TaskCreationForm({ selectedDate, onSuccess, onCancel }: TaskCreationFormProps) {
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState<Subject | ''>('');
  const [chapter, setChapter] = useState('');
  const [duration, setDuration] = useState('');

  const addTaskMutation = useAddTask();

  const chapters = {
    physics: ['Mechanics', 'Thermodynamics', 'Optics', 'Electromagnetism', 'Modern Physics'],
    chemistry: ['Physical Chemistry', 'Organic Chemistry', 'Inorganic Chemistry', 'Environmental Chemistry'],
    biology: ['Cell Biology', 'Genetics', 'Ecology', 'Human Physiology', 'Plant Physiology'],
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !subject || !chapter || !duration) {
      alert('Please fill all fields');
      return;
    }

    const dateTimestamp = BigInt(selectedDate.getTime() * 1000000); // Convert to nanoseconds

    await addTaskMutation.mutateAsync({
      title,
      subject: subject as Subject,
      chapterName: chapter,
      durationEstimate: BigInt(parseInt(duration)),
      date: dateTimestamp,
    });

    setTitle('');
    setSubject('');
    setChapter('');
    setDuration('');
    onSuccess();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="title">Task Title</Label>
        <Input
          id="title"
          placeholder="e.g., Complete Mechanics chapter"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Subject</Label>
          <Select
            value={subject}
            onValueChange={(value) => {
              setSubject(value as Subject);
              setChapter('');
            }}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select subject" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="physics">Physics</SelectItem>
              <SelectItem value="chemistry">Chemistry</SelectItem>
              <SelectItem value="biology">Biology</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Chapter</Label>
          <Select value={chapter} onValueChange={setChapter} disabled={!subject}>
            <SelectTrigger>
              <SelectValue placeholder="Select chapter" />
            </SelectTrigger>
            <SelectContent>
              {subject &&
                chapters[subject as keyof typeof chapters].map((ch) => (
                  <SelectItem key={ch} value={ch}>
                    {ch}
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="duration">Estimated Duration (minutes)</Label>
        <Input
          id="duration"
          type="number"
          placeholder="e.g., 60"
          value={duration}
          onChange={(e) => setDuration(e.target.value)}
          min="1"
        />
      </div>

      <div className="flex gap-2">
        <Button type="submit" disabled={addTaskMutation.isPending} className="flex-1">
          {addTaskMutation.isPending ? 'Adding...' : 'Add Task'}
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  );
}
