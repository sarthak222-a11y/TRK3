import { useEffect, useState } from 'react';
import { Calendar, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface CountdownData {
  days: number;
  hours: number;
  minutes: number;
}

export default function CountdownWidget() {
  const [examDate, setExamDate] = useState<Date>(() => {
    const saved = localStorage.getItem('neetExamDate');
    return saved ? new Date(saved) : new Date('2026-05-03'); // Default NEET 2026 date
  });
  const [countdown, setCountdown] = useState<CountdownData>({ days: 0, hours: 0, minutes: 0 });
  const [motivationalMessage, setMotivationalMessage] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [dateInput, setDateInput] = useState('');

  useEffect(() => {
    const calculateCountdown = () => {
      const now = new Date();
      const diff = examDate.getTime() - now.getTime();

      if (diff <= 0) {
        setCountdown({ days: 0, hours: 0, minutes: 0 });
        setMotivationalMessage('Exam day is here! Give your best! 🎯');
        return;
      }

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

      setCountdown({ days, hours, minutes });

      // Set motivational message based on days remaining
      if (days > 100) {
        setMotivationalMessage('Build your foundation strong! 📚');
      } else if (days > 30) {
        setMotivationalMessage('Intensify your revision! 🔥');
      } else if (days > 7) {
        setMotivationalMessage('Final push - you got this! 💪');
      } else {
        setMotivationalMessage('Stay calm and confident! 🌟');
      }
    };

    calculateCountdown();
    const interval = setInterval(calculateCountdown, 60000); // Update every minute

    return () => clearInterval(interval);
  }, [examDate]);

  const handleSaveDate = () => {
    if (dateInput) {
      const newDate = new Date(dateInput);
      setExamDate(newDate);
      localStorage.setItem('neetExamDate', newDate.toISOString());
      setIsDialogOpen(false);
    }
  };

  return (
    <Card className="bg-gradient-to-br from-success/10 to-success/5 border-success/20">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-2xl flex items-center gap-2">
            <Calendar className="w-6 h-6 text-success" />
            NEET 2026 Countdown
          </CardTitle>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                Set Date
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Set NEET Exam Date</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="exam-date">Exam Date</Label>
                  <Input
                    id="exam-date"
                    type="date"
                    value={dateInput}
                    onChange={(e) => setDateInput(e.target.value)}
                  />
                </div>
                <Button onClick={handleSaveDate} className="w-full">
                  Save Date
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-center gap-8 py-6">
          <div className="text-center">
            <div className="text-5xl font-bold text-success">{countdown.days}</div>
            <div className="text-sm text-muted-foreground mt-1">Days</div>
          </div>
          <div className="text-4xl text-muted-foreground">:</div>
          <div className="text-center">
            <div className="text-5xl font-bold text-success">{countdown.hours}</div>
            <div className="text-sm text-muted-foreground mt-1">Hours</div>
          </div>
          <div className="text-4xl text-muted-foreground">:</div>
          <div className="text-center">
            <div className="text-5xl font-bold text-success">{countdown.minutes}</div>
            <div className="text-sm text-muted-foreground mt-1">Minutes</div>
          </div>
        </div>
        <div className="text-center mt-4">
          <p className="text-lg font-medium text-foreground">{motivationalMessage}</p>
        </div>
      </CardContent>
    </Card>
  );
}
