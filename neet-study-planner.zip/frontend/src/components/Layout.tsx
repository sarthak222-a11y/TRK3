import { Outlet, useNavigate, useRouterState } from '@tanstack/react-router';
import { BookOpen, BarChart3, Target, Timer, CheckSquare, TrendingUp, Settings } from 'lucide-react';

export default function Layout() {
  const navigate = useNavigate();
  const routerState = useRouterState();
  const currentPath = routerState.location.pathname;

  const navItems = [
    { path: '/', label: 'Dashboard', icon: BookOpen },
    { path: '/timer', label: 'Study Timer', icon: Timer },
    { path: '/tasks', label: 'Tasks', icon: CheckSquare },
    { path: '/syllabus', label: 'Syllabus', icon: Target },
    { path: '/checkpoints', label: 'Checkpoints', icon: Target },
    { path: '/analytics', label: 'Analytics', icon: BarChart3 },
    { path: '/insights', label: 'Insights', icon: TrendingUp },
    { path: '/settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-success flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-success-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">NEET Study Planner</h1>
                <p className="text-xs text-muted-foreground">Your path to 700+</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <nav className="border-b border-border bg-card/50 sticky top-[73px] z-40">
        <div className="container mx-auto px-4">
          <div className="flex gap-1 overflow-x-auto">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPath === item.path;
              return (
                <button
                  key={item.path}
                  onClick={() => navigate({ to: item.path })}
                  className={`flex items-center gap-2 px-4 py-3 text-sm font-medium whitespace-nowrap transition-colors border-b-2 ${
                    isActive
                      ? 'border-success text-success bg-success/5'
                      : 'border-transparent text-muted-foreground hover:text-foreground hover:bg-muted/50'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-8">
        <Outlet />
      </main>

      <footer className="border-t border-border bg-card mt-16">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center text-sm text-muted-foreground">
            <p>
              © {new Date().getFullYear()} NEET Study Planner. Built with ❤️ using{' '}
              <a
                href={`https://caffeine.ai/?utm_source=Caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(
                  typeof window !== 'undefined' ? window.location.hostname : 'neet-planner'
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-success hover:underline"
              >
                caffeine.ai
              </a>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
