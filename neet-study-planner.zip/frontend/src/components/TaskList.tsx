import { CheckCircle2, Circle, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { useGetTasks, useCompleteTask } from '@/hooks/useQueries';

interface TaskListProps {
  selectedDate: Date;
}

export default function TaskList({ selectedDate }: TaskListProps) {
  const { data: allTasks = [], isLoading } = useGetTasks();
  const completeTaskMutation = useCompleteTask();

  // Filter tasks for selected date
  const selectedDateOnly = new Date(selectedDate);
  selectedDateOnly.setHours(0, 0, 0, 0);

  const tasksForDate = allTasks.filter((task) => {
    const taskDate = new Date(Number(task.date) / 1000000);
    taskDate.setHours(0, 0, 0, 0);
    return taskDate.getTime() === selectedDateOnly.getTime();
  });

  const handleToggleComplete = async (taskId: bigint, completed: boolean) => {
    if (!completed) {
      await completeTaskMutation.mutateAsync(taskId);
    }
  };

  const getSubjectColor = (subject: string) => {
    switch (subject) {
      case 'physics':
        return 'bg-chart-1/10 text-chart-1 border-chart-1/20';
      case 'chemistry':
        return 'bg-chart-2/10 text-chart-2 border-chart-2/20';
      case 'biology':
        return 'bg-chart-3/10 text-chart-3 border-chart-3/20';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-8">
          <div className="text-center text-muted-foreground">Loading tasks...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>
          Tasks for {selectedDate.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {tasksForDate.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No tasks scheduled for this date. Click "Add Task" to create one.
          </div>
        ) : (
          <div className="space-y-3">
            {tasksForDate.map((task) => (
              <div
                key={Number(task.id)}
                className={`flex items-start gap-3 p-4 rounded-lg border-2 transition-all ${
                  task.completed
                    ? 'bg-success/5 border-success/20'
                    : 'bg-card border-border hover:border-success/30'
                }`}
              >
                <Checkbox
                  checked={task.completed}
                  onCheckedChange={() => handleToggleComplete(task.id, task.completed)}
                  disabled={task.completed || completeTaskMutation.isPending}
                  className="mt-1"
                />
                <div className="flex-1 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <h3
                      className={`font-medium ${
                        task.completed ? 'line-through text-muted-foreground' : 'text-foreground'
                      }`}
                    >
                      {task.title}
                    </h3>
                    {task.completed && <CheckCircle2 className="w-5 h-5 text-success flex-shrink-0" />}
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant="outline" className={getSubjectColor(task.subject)}>
                      {task.subject.charAt(0).toUpperCase() + task.subject.slice(1)}
                    </Badge>
                    <span className="text-sm text-muted-foreground">{task.chapterName}</span>
                    <span className="text-sm text-muted-foreground flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {Number(task.durationEstimate)} min
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
